package A6;

/*
 * 
 * write a program that creates a LinkedList object of 
 * 10 characters,then creates a second LinkedList object
 * containing a copy of the first list, but in reverse order
 * 
 * 
 * */


import java.util.Collections;
import java.util.LinkedList;
import java.util.Scanner;

public class Main {

	private static Scanner input;

	public static void main(String[] args) {

		
		LinkedList<String> list = new LinkedList<String>();
		LinkedList<String> sec_list = new LinkedList<String>();
		
		input = new Scanner(System.in);

		// read a LinkedList object of 10 characteres.
		System.out.println("Please, insert 10 elements:");
		for (int i = 0; i < 10; i++) {	
			list.add(input.next());
		}
		
		//Clone original list o second list.
        sec_list =  (LinkedList<String>) list.clone(); 
		System.out.println(list);
		
		mirror(sec_list); //call mirror method
	}
	
	
	public static void mirror(LinkedList<String> sec_list) {
		
			  Collections.reverse(sec_list); //reverse string
			  System.out.println(sec_list);

	}
}
