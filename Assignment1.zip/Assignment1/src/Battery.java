import java.util.concurrent.Executors;
import java.util.concurrent.ScheduledExecutorService;
import java.util.concurrent.TimeUnit;

/**
 * 
 * Rachel Beraldo Bittar
 * ID: 301006074
 * 
 * 
 * Write a class Battery that models a rechargeable battery. A battery has a
 * constructor Battery(double capacity) Where capacity is a value measured in
 * milliampere hours. A typical AA battery has a capacity of 2000 to 3000 mAh.
 * The method public void drain(double amount) drains the capacity of the
 * battery by the given amount. The method public void charge() charges the
 * battery to its original capacity. The method public double
 * getRemainingCapacity() gets the remaining capacity of the battery.
 */

public class Battery {

	double capCurrent;
	double capRemaning;

	public Battery(double capacity) {
		this.capCurrent = capacity;
		this.capRemaning = capacity;
	}

	public void Drain(double amount) {
		capRemaning = capRemaning - amount;
	}

	public void keepDraining(double amount, int timer) {
		Runnable drainRunnable = new Runnable() {
			public void run() {
				Drain(amount);
				if (capRemaning <= 0) {
					System.out.println("0 Battery, Please charge");
				} else {
					System.out.println("\nKeeping Draining: " + getRemainingCapacity());
				}
			}
		};
		ScheduledExecutorService executor = Executors.newScheduledThreadPool(1);
		executor.scheduleAtFixedRate(drainRunnable, 0, timer, TimeUnit.SECONDS);
	}

	public void Charge() {
		capRemaning = capCurrent;
	}

	public double getRemainingCapacity() {
		return capRemaning;
	}

}
