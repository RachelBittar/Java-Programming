import java.util.Scanner;

public class Main {

	public static void main(String[] args) {
		
		double capacity;
		
		Scanner input = new Scanner(System.in);
	
		System.out.print("Please add capacity: ");
		capacity = input.nextDouble();
		
		if(capacity<2000 || capacity>3000) {
			System.out.println("Capacity must be between 2000 and 3000");
		}
		else{	
	
			Battery battery = new Battery(capacity);
			System.out.println("Inicial: "+ battery.getRemainingCapacity());
		
			battery.Charge();
			System.out.println("Charge: "+ battery.getRemainingCapacity());
			
			System.out.print("Value to drain: ");
			double drain = input.nextDouble();
    		battery.Drain(drain);
			System.out.println("Inicial: "+ battery.getRemainingCapacity());
			
		    battery.keepDraining(drain, 3); 
			System.out.println(battery.getRemainingCapacity());

		    		 
		}
	}
		
}
