import java.security.SecureRandom;
import java.util.ArrayList;

public class Message {

	ArrayList<String> message = new ArrayList<String>();
	ArrayList<String> range = new ArrayList<String>();

	public void reply(ArrayList<String> message, ArrayList<String> range) {

		SecureRandom randomNumber = new SecureRandom();
		int i = randomNumber.nextInt(message.size());
		System.out.println(message.get(i) + " " + range.get(i));
	}

	public void reply(ArrayList<String> message) {

		SecureRandom randomNumber = new SecureRandom();
		int i = randomNumber.nextInt(message.size());
		System.out.println(message.get(i));
	}
}
