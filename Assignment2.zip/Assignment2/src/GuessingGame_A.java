import java.security.SecureRandom;

public class GuessingGame_A {
	
	private int guess = 0;
	
	static SecureRandom randomNumber = new SecureRandom();
	private static final int target = 1 + randomNumber.nextInt(1000);
	
	public GuessingGame_A(int n) {
		guess = n;
	}
	
	public void Target() {
		System.out.println(target);
	}

	public boolean CheckResult() {
		
		if(target == guess) {
			System.out.println("Congratulations! You found the number.");
			return true;
		}
		if(target > guess) {
			System.out.println("Too low! Try again.");	
			return false;
		}
		else{
			System.out.println("Too high! Try again.");
			return false;
		}
		
	}
}