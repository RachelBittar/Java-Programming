
/*
 * Rachel Bittar
 * ID : 301006074
 * 
 *  PART B
 * 
 * 
 * */


import java.util.Scanner;

public class Main_B {

	private static Scanner input;

	public static void main(String[] args) {
		int att=0;
		int n;
		boolean correct=false;
		Message answer = new Message();
		
		Gamer gamer = new Gamer();
		input = new Scanner(System.in);
		
		System.out.println("---------Welcome to GuessingGame Part B!-----------");
		
		System.out.println("Tell me, how is your mood today Good or are you a little upset?");
		gamer.setMood(input.nextLine().toLowerCase());
		
		if(gamer.ClassByMood()) { 
			
			System.out.println("Can I have your name?");
			gamer.setName(input.nextLine());
			
			System.out.println("Do you have a nickname?");
			gamer.setNickname(input.nextLine());
			
			System.out.println("Are you ready "+gamer.getNickname()+"? Please, guess a number from 1 to 1000");
		}
		
		else {
			System.out.println("What is your name?");
			gamer.setName(input.nextLine());
			System.out.println( gamer.getName()+" guess a number from 1 to 1000...");
		}
		
		while(!correct) {	
			att++;
			
			n= input.nextInt();
			
			if(gamer.ClassByMood()) {
				 new HappyGame(n);
				 correct = HappyGame.CheckResult();
					if(!correct) {
						answer.reply (HappyGame.LoadmsgWrong(),HappyGame.ValidateResultMessage());
					}
					else {
						answer.reply(HappyGame.LoadmsgCorrect());
					}	
			}
			else { 
				new AngryGame(n);
			    correct = AngryGame.CheckResult();
				if(!correct) {
					answer.reply(AngryGame.LoadmsgWrong(),AngryGame.ValidateResultMessage());
				}
				else {
					answer.reply(AngryGame.LoadmsgCorrect());
				}	
			  }
			}
		
		System.out.println( gamer.getName()+" got it in "+att+" attempts!");
	}
	
}
