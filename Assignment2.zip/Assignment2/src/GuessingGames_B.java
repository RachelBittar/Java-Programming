import java.security.SecureRandom;


public class GuessingGames_B {

	private static int guess = 0;

	static SecureRandom randomNumber = new SecureRandom();
	private static final int target = 1 + randomNumber.nextInt(1000);

	public GuessingGames_B(int n) {
		this.guess = n;
	}

	public static boolean CheckResult() {
		if (target == guess) {
			return true;
		} 
		else {
			CheckRange();
			return false;
		}
	}

	public static String CheckRange() {
		int result;
		result = guess - target;

		if ((result > 0) && (result < 200)) {
			return "CheckRangeHigh";
		}
		if (result >= 200) {
			return "CheckRangeTooHigh";
		}
		if ((result < 0) && (result > -200)) {
			return "CheckRangeLow";
		}
		if (result <= -200) {
			return "CheckRangeTooLow";
		}
		
		return "error";
	}
}