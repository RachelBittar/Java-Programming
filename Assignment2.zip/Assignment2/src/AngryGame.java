
import java.util.ArrayList;

public class AngryGame extends GuessingGames_B{
	
	private static ArrayList<String> message =  new ArrayList<String>();
	public AngryGame(int n) {
		super(n);
	}
	
	public static ArrayList<String> ValidateResultMessage() {	
		
		if(!CheckResult()) {
			if(CheckRange().equals("CheckRangeTooHigh") ) { 		
				return LoadmsgWrongTooHigh();
			}
			if(CheckRange().equals("CheckRangeHigh") ) {
				return LoadmsgWrongHigh();
			}
			if(CheckRange().equals("CheckRangeLow") ) {
				return LoadmsgWrongLow();
			}
			if(CheckRange().equals("CheckRangeTooLow") ) {
				return LoadmsgWrongTooLow();
			}
			
			
		}
		else 
			 message = LoadmsgCorrect(); return message;		
	}
	



	public static ArrayList<String> LoadmsgWrongLow() {
		
	    ArrayList<String> range =  new ArrayList<String>();
	    range.add("Arrg,Low!");
	    range.add("Low! Come on, increase it next time.");
	    range.add("Low! Your target is higher than that!");	
	    
	    return  range;
	}
	
	public static ArrayList<String> LoadmsgWrongHigh() {
		
	    ArrayList<String> range =  new ArrayList<String>();
	    range.add("Your guess is higher than it should be.");
	    range.add("High! Decrease it!");
	    range.add("Your guess is higher than the target...");	
	    
	    return  range;
	}
	
	public static ArrayList<String> LoadmsgWrongTooLow() {
		
	    ArrayList<String> range =  new ArrayList<String>();
	    range.add("Yor guess is too low, You are getting closer");
	    range.add("Duh, Guess is Too low.");
	    range.add("Guess Too low...");	
	    
	    return  range;
	}
	
	public static ArrayList<String> LoadmsgWrongTooHigh() {
		
	    ArrayList<String> range =  new ArrayList<String>();
	    range.add("Your guess is too high! Will you take forever?");
	    range.add("Your target is way lower than this...");
	    range.add("Come on! This is too high!");	
	    
	    return  range;
	}
	
	public static ArrayList<String> LoadmsgWrong() {
		
	    ArrayList<String> range =  new ArrayList<String>();
	    range.add("Wrong!");
	    range.add("No! Wrong again.");
	    range.add("Error!");	
	    
	    return  range;
	}	
	
	public static ArrayList<String> LoadmsgCorrect() {
		
	    ArrayList<String> range =  new ArrayList<String>();
	    range.add("Finally...");
	    range.add("Right, bye now.");
	    range.add("Right, but not a big deal.");	
	    
	    return  range;
	}
		
}
