import java.util.Scanner;



/*
 * Rachel Bittar
 * ID : 301006074
 * 
 *  PART A
 * 
 * 
 * */


public class Main_A {

	public static void main(String[] args) {
		
		boolean correct = false;
		int att=0, n=0;
		Scanner input = new Scanner(System.in);
		String name;
		
		System.out.println("---------Welcome to GuessingGame Part A!-----------");
		System.out.println("What is your name?");
		name = input.nextLine();
		System.out.println( name+" guess a number from 1 to 1000...");
		
		while(!correct) {	
			att++;
			n= input.nextInt();
			GuessingGame_A gm = new GuessingGame_A(n);
			correct = gm.CheckResult();
		}
		
		System.out.println( name +" got it in "+att+" attempts!");

	}

}
