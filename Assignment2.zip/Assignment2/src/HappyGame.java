import java.util.ArrayList;

public class HappyGame extends GuessingGames_B{
	private static ArrayList<String> message =  new ArrayList<String>();
	public HappyGame(int n) {
		super(n);
	}
	
	public static ArrayList<String> ValidateResultMessage() {	
		
		if(!CheckResult()) {
			if(CheckRange().equals("CheckRangeTooHigh") ) { 		
				return LoadmsgWrongTooHigh();
			}
			if(CheckRange().equals("CheckRangeHigh") ) {
				return LoadmsgWrongHigh();
			}
			if(CheckRange().equals("CheckRangeLow") ) {
				return LoadmsgWrongLow();
			}
			if(CheckRange().equals("CheckRangeTooLow") ) {
				return LoadmsgWrongTooLow();
			}

			
		}
		else 
			 message = LoadmsgCorrect(); return message;		
	}
	
	public static ArrayList<String> LoadmsgWrongLow() {
		
	    ArrayList<String> range =  new ArrayList<String>();
	    range.add("Your guess is lower than target, but not too much.");
	    range.add("This number is lower, increase a little bit., but you are almoooost there.");
	    range.add("Your guess sitll lower, keep trying. You will be there soon.");	
	    range.add("Your guess lower, keep trying. You will be there soon.");	
	    
	    return  range;
	}
	
	public static ArrayList<String> LoadmsgWrongHigh() {
		
	    ArrayList<String> range =  new ArrayList<String>();
	    range.add("Your guess is higher than target, but not too much.");
	    range.add("This number is high, decrese a little bit.");
	    range.add("This is Higher than the target, try lower a different number.");	
	    range.add("This is Higher, try lower a different number.");	
	    
	    return  range;
	}
	
	public static ArrayList<String> LoadmsgWrongTooLow() {
		
	    ArrayList<String> range =  new ArrayList<String>();
	    range.add("Your guess is too low. You are getting closer.");
	    range.add("This number is too low from the target.");
	    range.add("Too low, increase a little bit.");	
	    range.add("Too low, increase your guess.");	
	    
	    return  range;
	}
	
	public static ArrayList<String> LoadmsgWrongTooHigh() {
		
	    ArrayList<String> range =  new ArrayList<String>();
	    range.add("Your guess is too high from the target.");
	    range.add("Your guess is too high, way different.");
	    range.add("Too high, try a different range.");	
	    range.add("Too high, try a different number.");
	    
	    return  range;
	}
	
	
	public static ArrayList<String> LoadmsgWrong() {
		
	    ArrayList<String> range =  new ArrayList<String>();
	    range.add("Not yet.");
	    range.add("Sorry.");
	    range.add("Keep trying!");	
	    range.add("Don't give up!");	
	    
	    return  range;
	}
	
	
	public static ArrayList<String> LoadmsgCorrect() {
		
	    ArrayList<String> range =  new ArrayList<String>();
	    range.add("Very Good.");
	    range.add("You got it.");
	    range.add("Nail it.");
	    range.add("Congratulations. You have found the number");
	    
	    return  range;
	}
	
		
}


