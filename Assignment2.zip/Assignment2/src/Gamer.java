
public class Gamer {
	
	private String name;
	private String nickname;
	private String mood;

	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	public String getNickname() {
		return nickname;
	}
	public void setNickname(String nickname) {
		this.nickname = nickname;
	}
	
	public void setMood(String mood) {
		this.mood = mood;
	}
	public boolean ClassByMood() {	
		if( mood.contains("good")) {
			return true;
		}
		return false;
	}

}
