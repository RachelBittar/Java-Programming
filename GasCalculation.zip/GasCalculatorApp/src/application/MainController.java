package application;

import javafx.application.Platform;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.scene.control.Button;
import javafx.scene.control.Label;
import javafx.scene.control.RadioButton;
import javafx.scene.control.TextArea;
import javafx.scene.control.TextField;
import javafx.scene.control.ToggleGroup;

public class MainController {

    @FXML private TextField lb_distancia;

    @FXML private TextField lb_consumo;

    @FXML private Button botao;

    @FXML private RadioButton rd_gallon;

    @FXML private ToggleGroup fuelGroup;

    @FXML private RadioButton rd_litter;

    @FXML private TextField txt_valor;

    @FXML private RadioButton rb_miles;

    @FXML private ToggleGroup distanceGroup;

    @FXML private RadioButton rb_km;

    @FXML private TextArea txt_area;

    @FXML private Label lb_currency;

    @FXML private TextArea txt_area_dist;
    
    @FXML private RadioButton rd_can;

    @FXML private RadioButton rd_usa;

    @FXML private TextArea txt_area1;

    @FXML private TextArea txt_area11;
    
    @FXML private ToggleGroup priceGroup;
    
    @FXML private TextArea txt_area_result;
    
    @FXML private Button btnExit;
    
    private double price =0;
    private double distance =0;
    private double consumido=0;
    private String unidadeD ="";
    private String unidadeP ="";
    private String unidadeC ="";
    
    private String unidadeDD ="";
    private String unidadeCC ="";
    private String unidadePP ="";
    
    
    private double unidade_nd ;
    private double unidade_np ;
    private double unidade_nc ;
    
    
   
    @FXML void acaodobotao(ActionEvent event) {
    	
    	
    	try {
			
    		consumido = Double.parseDouble(lb_consumo.getText());
        	distance = Double.parseDouble(lb_distancia.getText());
        	price = Double.parseDouble(txt_valor.getText());
        	
		} catch (Exception e) {
			txt_area11.setText("Error");
		}
    	
   
    	txt_area11.setText(
    			"Distance: "+distance+  " "+unidadeD+"\n"+
    			"Consumed: "+consumido+ " "+unidadeC+"\n"+
    			"Price: "   +price+     " "+unidadeP+"\n"+
    			"Average: " +distance/consumido+" "+unidadeD+"/"+unidadeC  + "\n");
    	
   	
    	
    	txt_area_result.setText(
    			"Distance: "+unidade_nd+  " "+unidadeDD+"\n"+
    			"Consumed: "+unidade_nc+ " "+unidadeCC+"\n"+
    			"Price: "   +unidade_np+     " "+unidadePP+"\n"+
    			"Average: " +unidade_nd/unidade_np+" "+unidadeDD+"/"+unidadeCC  + "\n");
   	
    }

    @FXML
    void clean(ActionEvent event) {
    	unidadeC ="";
    	unidadeD ="";
    	unidadeP ="";
    	
    	txt_area11.setText("");
    	txt_area1.setText("");
    	txt_area.setText("");
    	txt_valor.setText("");
    	lb_distancia.setText("");
    	lb_consumo.setText("");
       	txt_area_dist.setText("");
       	txt_area_result.setText("");
    		

    }
    
    
    @FXML
    void buttonExit(ActionEvent event) {
    	
    	

    }
    
    
    
    
    

    @FXML
    void radioButton(ActionEvent event) {
    	
		double consumo=0;
		
		if(rd_gallon.isSelected()) {
			try {
				consumo = Double.parseDouble(lb_consumo.getText());;
				unidadeC = " Gallon";
				unidadeCC = " Liters";
				unidade_nc = consumo*3.78;
				
			} catch (Exception e) {
				
			lb_consumo.setText("Invalid Value");
		}
		
			txt_area.setText(("Equiv  "+(consumo*3.78)+ unidadeCC));
	}
		
	if(rd_litter.isSelected()) {
		
		consumo = 0;
		
		try {
			consumo = Double.parseDouble(lb_consumo.getText());
			unidadeC = " Litter";
			unidadeCC = " Gallons";
		} catch (Exception e) {
			lb_consumo.setText("Invalid Value");
		}
		
   		txt_area.setText(("Equiv "+(consumo/3.78)+unidadeCC));
   		unidade_nc = consumo/3.78;
   			
	}
				
    }

    @FXML
    void radioButtonDis(ActionEvent event) {
    	
    	
    	if(rb_miles.isSelected()) {
			
    		double consumo =0;
    		
    		try {
    			consumo = Double.parseDouble(lb_distancia.getText());
    			unidadeD = " Miles";
    			unidadeDD = " Km";
    			unidade_nd = consumo/1.60;
    			
			} catch (Exception e) {
				lb_distancia.setText("Invalid value");
			}
			
			distance = consumo;
			txt_area_dist.setText(("Equiv "+(consumo/1.60)+ unidadeDD));
		}
			
		if(rb_km.isSelected()) {
			
			double consumo =0;
			
			try {
				consumo = Double.parseDouble(lb_distancia.getText());
				unidadeD = " Km";
				unidadeDD = " Miles";
			} catch (Exception e) {
				lb_distancia.setText("Invalid value");
			}
			 
			
			txt_area_dist.setText(("Equiv "+(consumo*0.62)+unidadeDD));
			unidade_nd = consumo*0.62;
		}
    	

    }
    
    
    
    
    @FXML
    void radioButtonPrice(ActionEvent event) {
    	
    	if(rd_can.isSelected()) {		
			double consumo = 0;
			
			try {
				consumo =Double.parseDouble(txt_valor.getText());
				unidadeP = " $ CAN";
				unidadePP = " $ USA";
				unidade_np = consumo*1.34;
			} catch (Exception e) {
				txt_valor.setText("Invalid value");
			}
		
			txt_area1.setText(("Equiv "+(consumo*0.75)+ unidadePP));
		}
    	
    	
		if(rd_usa.isSelected()) {
			double consumo = 0;
			try 
			{
				consumo = Double.parseDouble(txt_valor.getText());
				unidadeP = "$ USA";
				unidadePP = "$ CAN";
				
			} catch (Exception e) {
	
				txt_valor.setText("Invalid value");
			}
					
			txt_area1.setText(("Equiv "+(consumo*1.34)+ unidadePP));
		}

    }
    
    
   
}
















//package application;
//
//import java.math.BigDecimal;
//import java.math.RoundingMode;
//import java.net.URL;
//import java.text.NumberFormat;
//import java.util.ResourceBundle;
//
//import javafx.css.converter.StringConverter;
//import javafx.event.ActionEvent;
//import javafx.fxml.FXML;
//import javafx.fxml.Initializable;
//import javafx.scene.control.Button;
//import javafx.scene.control.Label;
//import javafx.scene.control.RadioButton;
//import javafx.scene.control.TextArea;
//import javafx.scene.control.TextField;
//import javafx.scene.control.ToggleGroup;
//
//public class MainController implements Initializable{
//
//	private static NumberFormat currency = NumberFormat.getCurrencyInstance();
//	private static int distancy = 0;
//	private static double consumo  = 0;
//	private static double result = 0;
//	private static double liter  = 0;
//	private static double gallon = 0;
//	
//	@FXML private Button btn_start;	
//	
//	@FXML private TextField lb_distancia;
//	@FXML private TextField lb_consumo;
//	
//	@FXML private Label lb_result;
//    @FXML private Label lb_c;
//    @FXML private Label lb_d;
//
//	@FXML private RadioButton rd_gallon;
//    @FXML private RadioButton rd_litter;
//    @FXML private RadioButton rb_miles;
//    @FXML private RadioButton rb_km;
//   
//    @FXML private ToggleGroup fuelGroup;
//    @FXML private ToggleGroup distanceGroup;
//     
//    @FXML private TextArea txt_area;
//    
//    
//
//	@FXML 
//	private void acaodobotao(ActionEvent event) {	
//		try{	
//			
//			consumo = Double.parseDouble(lb_consumo.getText());	
//			lb_result.setText((""+consumo));
//			
//		} catch (Exception e) {
//			System.out.println("Error reading values");
//		}
//		
//	}
//	
//	@FXML 
//	private void radioButton(ActionEvent event) {	
//		
//		if(rd_gallon.isSelected()) {
//			lb_c.setText("Gallons");
//			consumo = Double.parseDouble(lb_consumo.getText());			
//			txt_area.setText((""+(consumo/3.78541)+"=> Liter"));
//		}
//			
//		if(rd_litter.isSelected()) {
//			lb_c.setText("Litters");
//			
//			consumo = Double.parseDouble(lb_consumo.getText());			
//			txt_area.setText((""+(consumo*3.78541)+"=> Gallons"));
//					
//		}
//		
//	}
//	
//	
//	@FXML 
//	private void radioButtonDis(ActionEvent event) {	
//		
//		if(rb_miles.isSelected()) {
//			lb_d.setText("Miles");
//			lb_c.setText("Gallons");
//			consumo = Double.parseDouble(lb_consumo.getText());			
//			txt_area.setText((""+(consumo/3.78541)+"=> Liter"));
//		}
//			
//		if(rb_km.isSelected()) {
//			lb_d.setText("Kilometros");
//		}
//		
//	}
//	
//	@FXML
//    void clean(ActionEvent event) {
//		lb_d.setText(" ");
//		lb_c.setText(" ");
//		lb_distancia.setText(" ");
//	    lb_consumo.setText(" ");
//	    lb_distancia.setText(" ");
//    }
//	
//
//	
//	@Override
//	public void initialize(URL location, ResourceBundle resources) {
//		// TODO Auto-generated method stub
//		
//	    lb_c.setText("Gallon");
//	    lb_d.setText("Kilometros");
//	    	   
//	}
//	
//
//
//	
//	
//}
